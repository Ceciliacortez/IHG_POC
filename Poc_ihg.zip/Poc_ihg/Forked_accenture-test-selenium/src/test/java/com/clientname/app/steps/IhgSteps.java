package com.clientname.app.steps;

import com.clientname.app.pages.IhgPage;

public class IhgSteps {
	IhgPage ihgPage = new IhgPage();

	public void doSearch(String destination, String adults) {

		IhgPage.setDestination(destination);


		IhgPage.setAdults(adults);
		IhgPage.clickSearchDestination();
		IhgPage.waitUntilPageLoads();
	}

}
