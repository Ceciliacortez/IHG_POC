package com.clientname.app.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.accenture.test.ui.WebDriverSession;

public class IhgPage extends WebDriverSession{
	public IhgPage() {
		PageFactory.initElements(getWebDriverSession(), this);
		
//		PageFactory.initElements(getWebDriverSession(), this);
		
	}

	@FindBy(css = "div.form-group.open-search input")
	public static WebElement searchBox;

	@FindBy(css = "div.htl-search")
	public static WebElement searchButton;

	@FindBy(css = "input.form-control.adults-input")
	public static WebElement adultInput;

	public static  void setDestination(String destination) {
		
		searchBox.sendKeys(destination);
		
	}
	public static void waitUntilPageLoads() {
		
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
public void waitUntilPageLoads(int secs) {
		
		try {
			Thread.sleep(secs*1000);
		} catch (Exception e) {
			// TODO: handle exception
		}	
		
	}
	public static  void setAdults(String adults) {
		adultInput.sendKeys(Keys.CONTROL+ "a" );
		adultInput.sendKeys(adults);
	}

	public static void clickSearchDestination() {
		searchButton.click();
	}
}
