package com.clientname.app.tests;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.accenture.test.ui.WebDriverSteps;
import com.clientname.app.pages.IhgPage;
import com.clientname.app.steps.IhgSteps;

public class IhgBasicTest {
IhgPage ihgPage = new IhgPage();
	
	IhgSteps ihgBehavior = new IhgSteps();
	private static final String DESTINY = "Villahermosa";
	private static final String ADULTS = "90";
	 @BeforeTest (alwaysRun = true)
	 public void beforeTest() throws IOException { 
		WebDriverSteps nav = new WebDriverSteps();
		nav.navigateToApplication("IHG");
		
	 }
	
	@Test
	public void searchTest() {
	    ihgPage.waitUntilPageLoads();
	    
		ihgBehavior.doSearch(DESTINY,ADULTS);
		
		assertTrue(WebDriverSteps.getWebDriverSession().
				getCurrentUrl().
				contains("/find-hotels/hotel/list"));
		WebDriverSteps.closeTheBrowser(); 
	}
	
}
