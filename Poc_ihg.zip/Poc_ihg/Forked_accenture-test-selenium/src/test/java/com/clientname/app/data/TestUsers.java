package com.clientname.app.data;

/**
 ****************************************************************************
 *HIGHLIGHTS:
 * > Class Example
 * > This is only an example of a class used to store data.
 * > Test users can be store in this class and then used on one or multiple scripts 
 ****************************************************************************
 */


public class TestUsers {

}
